import{l as o,a as r}from"../chunks/CDafY_Wt.js";export{o as load_css,r as start};
